document.addEventListener('DOMContentLoaded', () => {
    // Seletores
    const guessInput = document.getElementById('guess');
    const submitButton = document.getElementById('submit');
    const resultDiv = document.getElementById('result');
    const attemptsDiv = document.getElementById('attempts');

    // Variáveis do jogo
    const maxNumber = 100;
    let secretNumber = Math.floor(Math.random() * maxNumber) + 1;
    let attempts = 0;

    // Função para verificar o palpite
    function checkGuess() {
        const userGuess = parseInt(guessInput.value);
        attempts++;
        
        if (userGuess < 1 || userGuess > maxNumber) {
            resultDiv.textContent = 'Por favor, insira um número entre 1 e 100.';
        } else if (userGuess < secretNumber) {
            resultDiv.textContent = 'Muito baixo! Tente novamente.';
        } else if (userGuess > secretNumber) {
            resultDiv.textContent = 'Muito alto! Tente novamente.';
        } else {
            resultDiv.textContent = `Parabéns! Você acertou o número ${secretNumber} em ${attempts} tentativas.`;
            secretNumber = Math.floor(Math.random() * maxNumber) + 1; // Escolher um novo número
            attempts = 0; // Resetar tentativas
        }
        attemptsDiv.textContent = `Tentativas: ${attempts}`;
        guessInput.value = '';
    }

    // Adicionar evento de clique ao botão
    submitButton.addEventListener('click', checkGuess);

    // Adicionar evento de pressionar Enter no input
    guessInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            checkGuess();
        }
    });
});
