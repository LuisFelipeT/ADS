// scripts.js

document.addEventListener('DOMContentLoaded', () => {
    // Seletor de links de navegação
    const navLinks = document.querySelectorAll('.nav-link');

    // Seletor das seções
    const sections = document.querySelectorAll('section');

    // Função para mostrar a seção correspondente e ocultar as outras
    function showSection(sectionId) {
        sections.forEach(section => {
            if (section.id === sectionId) {
                section.style.display = 'block';
            } else {
                section.style.display = 'none';
            }
        });
    }

    // Inicialmente mostrar a seção de início
    showSection('home');

    // Adicionar eventos de clique aos links de navegação
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const sectionId = e.target.getAttribute('href').substring(1);
            showSection(sectionId);
        });
    });

    // Função para manipular o envio do formulário de contato
    const contactForm = document.getElementById('contact-form');
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;

        // Simular envio de formulário e mostrar mensagem de sucesso
        alert(`Obrigado, ${name}! Sua mensagem foi enviada com sucesso.\nE-mail: ${email}\nMensagem: ${message}`);

        // Limpar o formulário
        contactForm.reset();
    });
});
