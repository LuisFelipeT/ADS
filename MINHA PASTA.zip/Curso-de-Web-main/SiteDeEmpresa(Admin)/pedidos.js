const Orders = [
  {
     productsName: "Gabinete Aorus C700",
     productNumber: "23474",
     paymentStatus: "Reembolso",
     shipping: "Negado",
  },
  {
     productsName: "Intel Core I5",
     productNumber: "72956",
     paymentStatus: "Pago",
     shipping: "Entregue",
  },
  {
     productsName: "Geforce RTX 3090",
     productNumber: "00278",
     paymentStatus: "Vencido",
     shipping: "Entregue",
  },
  {
     productsName: "Water cooler Gigabyte",
     productNumber: "11848",
     paymentStatus: "Pago",
     shipping: "Pendente",
  },
  {
     productsName: "Teclado Logtech G Pro K",
     productNumber: "29572",
     paymentStatus: "Vencido",
     shipping: "Entregue",
  },
  {
     productsName: "Mouse Logtech G502",
     productNumber: "29572",
     paymentStatus: "Pago",
     shipping: "Pendente",
  },
];