//let carro= "volvo";

//alert("Alô mundo!");

//let a=5;
//let b=10;
//alert(a+b);

function Batata(){;
    alert("Você clicou em mim");
}
 
function multiplicapordois(valor){
    return valor*2;
}
let contador=0;

function ContaClique(){
    contador++;
    document.getElementById("RESULTADO").innerHTML = "O contator está com: "+contador +" cliques";
}


function ResetaConta(){
    contador--;
    document.getElementById("RESULTADO").innerHTML = "O contator está com: "+contador +" cliques";
}

 //{let a=8
//let b=8
//alert(16/2)
//}

function imparoupar(){
    let n= prompt("Digite um número");
    let total=n/2;
    let resultado=total%2==0?'par':'impar';
    alert(total+"é"+resultado);
}

function qualemaior(){
    let a = prompt("1");
    let b = prompt("5");
    if(a<b){
        alert("A é maior que B");
    }else{
        alert("B é maior que A");
    }
}
 
const form = document.getElementyById("form");
const username = document.getElementById("username");
const email = document.getElementById("email");
const senha = document.getElementById("senha");
const ConfirmeSuaSenha=document.getElementById("confirme-sua-senha")

form.addEventListener("submit", (e)=>{preventDefault; checkInputs();});

function checkInputs(){
    const usernameValue = username.value;
    const emailValue = email.value;
    const senhaValue = senha.value
    const confirmeSuaSenha = confirmeSuaSenha.value;
    if(usernameValue===""){
        setErrorFor(username,"O nome do usuário e obrigatório");
    }else{
        setSucessFor(username);
    }

    if(emailValue===""){
        setErrorFor(email,"O email é obrigatório");
    }else{
        setSucessFor(email);
    }

    if(senhaValue===""){
        setErrorFor(senha,"A senha é obrigatória");
    }else if(senhawordValue.length<7){
        setErrorFor(senha,"A senha precisa ter no mínimo 7 caracteres");
    }
    else{
        setSucessFor(senha);
    }
    if(confirmeSuaSenha===""){
        setErrorFor(confirmeSuaSenha, "Confirmação da sua senha é obrigatório")
    }else if(confirmeSuaSenhaValue !== senhaValue){
        setErrorFor(confirmeSuaSenha, "As senhas não conferem");
    }
    else{
        setSucessFor(confirmeSuaSenha);
    }
    const formControls = form.querSelectorAll(".form-control");
    const formIsValid = [...formControls].every((formControl)=>{
        return formControl.classname==="form-control sucess";
    });
if(fomIsValid) {
    console.log("O formulário está 100% válido!")
    }
}

function setErrorFor(input, message){
    const formControl = input.parentElement;
    const small = formControl.querySelector("small");
    //Adiciona a mensagem de erro
    small.innerText = message;
    //Adiciona a classe de erro
    formControl.className="form-control error";
}

function setSucessFor(input){
    const formControl = input.parentElement;
    //Adiciona a classe de sucesso
    formControl.className="form-control sucess";
}

function checkEmail(email){
    return /^[a-z0-9.]+@[a-z0-9]+\.[a-z]+\.([a-z]+)?$/i.test(email);
}